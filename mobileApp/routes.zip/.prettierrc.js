module.exports = {
  endOfLine:"auto",
  singleQuote: true,
  trailingComma: 'all',
};
