import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { Home } from '../src/home';
import { About } from '../src/about';
import { BallContainer } from '../src/ball';
import { Sensors } from '../src/sensors';

const Stack = createStackNavigator();

export function Navigation() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={Home} />
      <Stack.Screen name="About" component={About} />
      <Stack.Screen name="Game" component={BallContainer} />
      <Stack.Screen name="Sensors" component={Sensors} />
    </Stack.Navigator>
  );
}
