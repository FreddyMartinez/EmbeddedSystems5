import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, StyleSheet, LayoutChangeEvent } from 'react-native';
import { gyroscope } from 'react-native-sensors';

interface Position {
  width: number;
  height: number;
}

const BALL_SIZE = 50;

export function BallContainer() {
  const [layoutRef, setLayout] = useState({ width: 0, height: 0 });
  const [showBall, setShow] = useState(false);

  const onLayout = (event: LayoutChangeEvent) => {
    setLayout(event.nativeEvent.layout);
    setShow(true);
  };

  return (
    <View style={styles.container} onLayout={onLayout}>
      {showBall && <Ball layout={layoutRef} />}
    </View>
  );
}

export function Ball({ layout }: { layout: Position }) {
  const [ballPosition, setPosition] = useState({
    x: layout.width / 2 - 25,
    y: layout.height / 2 - 25,
  });
  const ballVelocity = useRef({ x: 0, y: 0 }).current;
  const ballAceleration = useRef({ x: 0, y: 0 }).current;

  useEffect(() => {
    const subscription = gyroscope.subscribe(({ x, y }) => {
      ballAceleration.y += x;
      ballAceleration.x += y;
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const calcPosition = useCallback(() => {
    ballVelocity.x += ballAceleration.x;
    ballVelocity.y += ballAceleration.y;

    let newX = ballPosition.x + ballVelocity.x;
    let newY = ballPosition.y + ballVelocity.y;

    if (newX <= 0) {
      newX = 0;
      ballVelocity.x = 0;
      ballAceleration.x = 0;
    } else if (newX > layout.width - BALL_SIZE) {
      newX = layout.width - BALL_SIZE;
      ballVelocity.x = 0;
      ballAceleration.x = 0;
    }

    if (newY <= 0) {
      newY = 0;
      ballVelocity.y = 0;
      ballAceleration.y = 0;
    } else if (newY > layout.height - BALL_SIZE) {
      newY = layout.height - BALL_SIZE;
      ballVelocity.y = 0;
      ballAceleration.y = 0;
    }

    setPosition({
      x: newX,
      y: newY,
    });

    requestAnimationFrame(calcPosition);
  }, []);

  useEffect(() => {
    const animationFrameId = requestAnimationFrame(calcPosition);
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [calcPosition]);

  return (
    <View
      style={[
        styles.ball,
        { left: Math.round(ballPosition.x), top: ballPosition.y },
      ]}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0fa',
  },
  ball: {
    width: BALL_SIZE,
    height: BALL_SIZE,
    borderRadius: BALL_SIZE / 2,
    backgroundColor: 'red',
    position: 'absolute',
  },
});
