import React from 'react';
import { Text, View } from 'react-native';

export function About() {
  return (
    <View>
      <Text>About</Text>
    </View>
  );
}
