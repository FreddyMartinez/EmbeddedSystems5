import React from 'react';
import { Text, View } from 'react-native';

export function Home() {
  return (
    <View>
      <Text>Home</Text>
    </View>
  );
}
