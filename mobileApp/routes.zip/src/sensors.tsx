import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import sensors from 'react-native-sensors';

type AvailableSensors = {
  [K in keyof typeof sensors]: string[];
};

export const Sensors = () => {
  const axis = ['x', 'y', 'z'];

  const availableSensors: Partial<AvailableSensors> = {
    accelerometer: axis,
    gyroscope: axis,
    magnetometer: axis,
  };

  return (
    <ScrollView>
      {Object.entries(availableSensors).map(([name, values]) => (
        <SensorView
          key={name}
          sensorName={name as keyof typeof sensors}
          values={values}
        />
      ))}
    </ScrollView>
  );
};

const SensorValue = ({ name, value }: { name: string; value: number }) => (
  <View style={styles.valueContainer}>
    <Text style={styles.valueName}>{name}:</Text>
    <Text style={styles.valueValue}>{new String(value).substring(0, 4)}</Text>
  </View>
);

export const SensorView = ({
  sensorName,
  values,
}: {
  sensorName: keyof typeof sensors;
  values: string[];
}) => {
  const sensor = sensors[sensorName];
  const initialValue = values.reduce(
    (carry, val) => ({ ...carry, [val]: 0 }),
    {},
  );
  const [sensorValues, setSensorValues] = useState(initialValue);
  const sensorSubscriptionRef = useRef();

  useEffect(() => {
    sensorSubscriptionRef.current = sensor.subscribe((readValues: any) => {
      setSensorValues({ ...readValues });
    });

    return () => {
      sensorSubscriptionRef.current.unsubscribe();
      sensorSubscriptionRef.current = null;
    };
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.headline}>{sensorName} values</Text>
      {values.map((valueName) => (
        <SensorValue
          key={sensorName + valueName}
          name={valueName}
          value={sensorValues[valueName]}
        />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
    marginTop: 50,
  },
  headline: {
    fontSize: 30,
    textAlign: 'left',
    margin: 10,
    color: '#333',
  },
  valueContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  valueValue: {
    width: 200,
    fontSize: 20,
    color: '#333',
  },
  valueName: {
    width: 50,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});

export default SensorView;
